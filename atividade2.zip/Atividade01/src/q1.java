
public class q1 {

}
